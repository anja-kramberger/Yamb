package com.comtrade.yamb.player;

import com.comtrade.yamb.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.*;

public class PlayableFields {

	public static List<Field> getAvailable(List<Field> fields) {
	    List<Field> available = new ArrayList<>();
	    for (Field field : fields) {
	        if (field.isPlayable() && !field.isPlayed()) {
	            available.add(field);
	        }
	    }
	    available.sort(Comparator.comparingInt(PriorityHandler::getPriority).reversed());
	    return available;
	}
	
}
