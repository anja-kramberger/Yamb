package com.comtrade.yamb.player;

import com.comtrade.yamb.*;
import java.util.*;


public class PatternProbability {
	
	public static Field findMostLikelyPattern(List<Field> availableFields, int[] dices, int throwNumber) {
	    Field bestField = null;
	    int highestProbability = -1;

	    for (Field field : availableFields) {
	        int probability = 0;

	        switch (field.getFieldType()) {
	            case MINIMUM:
	                probability = minimumProbability(dices);
	                break;
	            case MAXIMUM:
	                probability = maximumProbability(dices);
	                break;
	            case KENTA:
	                probability = kentaProbability(dices);
	                break;
	            case TRILING:
	                probability = trilingProbability(dices);
	                break;
	            case POKER:
	                probability = pokerProbability(dices);
	                break;
	            case FULL:
	                probability = fullProbability(dices);
	                break;
	            case YAMB:
	                probability = yambProbability(dices);
	                break;
	            case FIELD_1:
	                probability = numberFieldProbability(dices, 1);
	                break;
	            case FIELD_2:
	                probability = numberFieldProbability(dices, 2);
	                break;
	            case FIELD_3:
	                probability = numberFieldProbability(dices, 3);
	                break;
	            case FIELD_4:
	                probability = numberFieldProbability(dices, 4);
	                break;
	            case FIELD_5:
	                probability = numberFieldProbability(dices, 5);
	                break;
	            case FIELD_6:
	                probability = numberFieldProbability(dices, 6);
	                break;
			default:
				break;
	        }

	        if (probability > highestProbability) {
	            highestProbability = probability;
	            bestField = field;
	        }
	    }

	    return bestField;
	}
	
	public static int minimumProbability(int[] dice) {
		int[] brojanja = Utils.ponavljanje(dice);
		/*int[] brojanja = new int[Constants.DICE_COUNT];
		for(int i=0; i < Constants.DICE_COUNT; i++) {
			brojanja[dice[i]-1]++;
		}*/
		int niske = brojanja[0] + brojanja[1] + brojanja[2];
		int zbir = brojanja[0]*1 + brojanja[1]*2 + brojanja[2]*3;
		if(niske == 3 && zbir <=6) {
			return 60;
		}
		if(niske == 4 && zbir <10) {
			return 65;
		}
		return 0;
	}
	public static int maximumProbability(int[] dice) {
		int[] brojanja = Utils.ponavljanje(dice);
		int visoke = brojanja[3] + brojanja[4] + brojanja[5];
		int zbir = brojanja[3]*4 + brojanja[4]*5 + brojanja[5]*6;
		if(visoke == 3 && zbir >=16) {
			
			return 65;
		}
		if(visoke == 4 && zbir >= 21) {
			return 70;
		}
		return 0;
	}
	
	public static int kentaProbability(int[] dice) {
		int[] brojanja = Utils.ponavljanje(dice);
		int brojac = 0;
		for(int i=1; i<brojanja.length-1; i++) {
			if(brojanja[i] >= 1)
				brojac++;
		}
		if(brojac >= 4 ) {
			return 55;
		}
		if(brojac == 3 && (brojanja[0] >= 1 || brojanja[5] >= 1)) {
			return 30;
		}
		return 0;
	}
	
	public static int trilingProbability(int[] dice) {
		int[] brojanja = Utils.ponavljanje(dice);
		if(Utils.max(brojanja) == 2) {
			return 66;
		}
		return 0;
	}
	
	public static int pokerProbability(int[] dice) {
		int[] brojanja = Utils.ponavljanje(dice);
		if(Utils.max(brojanja) == 2) {
			return 13;
		}
		if(Utils.max(brojanja) == 3) {
			return 42;
		}
		return 0;
	}
	
	public static int fullProbability(int[] dice) {
		int[] brojanja = Utils.ponavljanje(dice);
		int dvojke = 0;
		int trojke = 0;
		for (int broj : brojanja) {
			if(broj == 2) {
				dvojke++;
			}
			if(broj == 3) {
				trojke++;
			}
		}
		if(dvojke == 2) {
			return 55;
		}
		if(trojke == 1) {
			return 30;
		}
		return 0;
	}
	
	public static int yambProbability(int[] dice) {
		int[] brojanja = Utils.ponavljanje(dice);
		int max = Utils.max(brojanja);
		if(max == 3) {
			return 8;
		}
		if(max == 4) {
			return 30;
		}
		return 0;
	}
	
	public static int numberFieldProbability(int[] dice, int number) {
	    int count = 0;
	    for (int die : dice) {
	        if (die == number) {
	            count++;
	        }
	    }
	    
	    switch (count) {
	        case 0: return 20;
	        case 1: return 40; 
	        case 2: return 60;  
	        case 3: return 75;  
	        case 4: return 90;
	        case 5: return 100;
	        default: return 0;
	    }
	}
}
