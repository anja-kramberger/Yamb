package com.comtrade.yamb.player;

import java.util.*;
import com.comtrade.yamb.ColumnType;
import com.comtrade.yamb.FieldType;
import com.comtrade.yamb.Field;


public class PriorityHandler {
	
	private static final Map<FieldType, Integer> fieldPriorities = new HashMap<>();
    private static final Map<ColumnType, Integer> columnPriorities = new HashMap<>();

    static {
        fieldPriorities.put(FieldType.YAMB, 100);
        fieldPriorities.put(FieldType.POKER, 90);
        fieldPriorities.put(FieldType.FULL, 85);
        fieldPriorities.put(FieldType.KENTA, 80);
        fieldPriorities.put(FieldType.TRILING, 75);
        fieldPriorities.put(FieldType.MAXIMUM, 72);
        fieldPriorities.put(FieldType.MINIMUM, 70);
        fieldPriorities.put(FieldType.FIELD_1, 80);
        fieldPriorities.put(FieldType.FIELD_6, 68);
        fieldPriorities.put(FieldType.FIELD_5, 65);
        fieldPriorities.put(FieldType.FIELD_4, 60);
        fieldPriorities.put(FieldType.FIELD_3, 55);
        fieldPriorities.put(FieldType.FIELD_2, 50);

        columnPriorities.put(ColumnType.RUCNA, 10);	
        columnPriorities.put(ColumnType.TOP_DOWN, 15);       
        columnPriorities.put(ColumnType.BOTTOM_UP, 15); 
        columnPriorities.put(ColumnType.FROM_MIDDLEPOINT, 12); 
        columnPriorities.put(ColumnType.FROM_ENDPOINT, 12);
        columnPriorities.put(ColumnType.NAJAVA, 8);
        columnPriorities.put(ColumnType.FREE, 5);
    }

    public static int getPriority(Field field) {
        int fieldScore = fieldPriorities.getOrDefault(field.getFieldType(), 0);
        int columnScore = columnPriorities.getOrDefault(field.getColumnType(), 0);
        return fieldScore + columnScore;
    }
	
}
