package com.comtrade.yamb.player;

import com.comtrade.yamb.Constants;

public class Utils {
	public static int max(int[] brojevi) {
		int max = Integer.MIN_VALUE;
		for (int i = 0; i < brojevi.length; i++) {
			if (brojevi[i] > max) 
				max = brojevi[i];
		}
		return max;
	}
	public static int min(int[] brojevi) {
		int min = Integer.MAX_VALUE;
		for(int i=0; i < brojevi.length; i++) {
			if(brojevi[i] < min) 
				min = brojevi[i];
		}
		return min;
	}
	public static boolean fullCheck(int[] brojevi) {
		int dvojke = 0;
		int trojke = 0;
		for (int count : brojevi) {
	        if (count == 2) dvojke++;
	        if (count == 3) trojke++;
	    }
		return (dvojke==1 && trojke ==1) || (trojke == 2);
	}
	
	//232456
	//021111
	public static int[] ponavljanje(int[] kockice) {
		int[] brojanja = new int[Constants.DICE_COUNT];
		for(int i=0; i<Constants.DICE_COUNT; i++) {
			brojanja[kockice[i]-1]++;
		}
		return brojanja;
	}
	public static int vratiIndeks(int[] kockice) {
		int indeks = 0;
		int max = 0;
		for(int i=0; i<kockice.length; i++) {
			if(max<kockice[i]) {
				indeks = i;
			}
		}
		return indeks;
	}
	public static int indexOfMax(int[] array) {
	    int maxIndex = 0;
	    int maxValue = array[0];
	    for (int i = 1; i < array.length; i++) {
	        if (array[i] > maxValue) {
	            maxValue = array[i];
	            maxIndex = i;
	        }
	    }
	    return maxIndex;
	}
}
