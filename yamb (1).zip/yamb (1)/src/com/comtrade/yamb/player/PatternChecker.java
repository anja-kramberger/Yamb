package com.comtrade.yamb.player;

import com.comtrade.yamb.Constants;
import com.comtrade.yamb.*;
import java.util.*;

public class PatternChecker {
	
	public static Field findBestPattern(List<Field> availableFields, int[] dice, ColumnType column) {
	    //int[] counts = Utils.ponavljanje(dice); 
	    
		List<FieldType> priorityOrder = Arrays.asList(
	        FieldType.YAMB,
	        FieldType.POKER,
	        FieldType.FULL,
	        FieldType.KENTA,
	        FieldType.TRILING,
	       /*FieldType.FIELD_6,
	        FieldType.FIELD_5,
	        FieldType.FIELD_4,
	        FieldType.FIELD_3,
	        FieldType.FIELD_2,
	        FieldType.FIELD_1,*/
	        FieldType.MAXIMUM,
	        FieldType.MINIMUM
	    );

	    for (FieldType type : priorityOrder) {
	        for (Field field : availableFields) {
	            if (field.getFieldType() == type && matchesPattern(type, dice, column )) {
	                return field;
	            }
	        }
	    }
	    return null;
	}

	private static boolean matchesPattern(FieldType type,  int[] dice,ColumnType column) {
	    switch (type) {
	        case YAMB:
	        	return isYamb(dice);
	        case POKER:
	        	return isPoker(dice);
	        case FULL:
	        	return isFull(dice);
	        case KENTA:
	        	return isKenta(dice);
	        case TRILING:
	        	return isTriling(dice, column);
	       /* case FIELD_1: case FIELD_2: case FIELD_3:
	        case FIELD_4: case FIELD_5: case FIELD_6:
	            //int target = Integer.parseInt(type.name().split("_")[1]);
	            return counts[target - 1] > 0;*/
	        case MAXIMUM:
	        	return isMinimum(dice);
	        case MINIMUM:
	        	return isMaximum(dice);
	        default:
	            return false;
	    }
	}

	public static Field findMostLikelyPattern(List<Field> availableFields, int[] dice, int throwNumber) {
        int[] counts = new int[6];
        for (int die : dice) {
            counts[die - 1]++;
        }
        
        int targetNumber = -1;
        int maxCount = 0;
        for (int i = 0; i < counts.length; i++) {
            if (counts[i] > maxCount) {
                maxCount = counts[i];
                targetNumber = i + 1; 
            }
        }

        if (maxCount < 3) {
            return null;
        }

        List<Field> candidateFields = new ArrayList<>();
        FieldType targetFieldType = FieldType.valueOf("FIELD_" + targetNumber);
        for (Field field : availableFields) {
            if (field.getFieldType() == targetFieldType) {
                candidateFields.add(field);
            }
        }

        if (candidateFields.isEmpty()) {
            return null;
        }

        Field best = candidateFields.get(0);
        int bestScore = PriorityHandler.getPriority(best);
        for (Field f : candidateFields) {
            int score = PriorityHandler.getPriority(f);
            if (score > bestScore) {
                best = f;
                bestScore = score;
            }
        }

        return best;
    }

	
	private static final int TRILING = 3;
	private static final int POKER = 4;
	private static final int YAMB = 5;
	
	
	public static boolean isMinimum(int[] dice) {
		int minimum = 0;
		for(int i=0; i<Constants.DICE_COUNT; i++) {
			minimum +=dice[i];
		}
		minimum -= Utils.max(dice);
		if(minimum <= 9) {
			return true;
		}
		return false;
	}
	public static boolean isMaximum(int[] dice) {
		int maximum = 0;
		for(int i=0; i < Constants.DICE_COUNT; i++) {
			maximum += dice[i];
		}
		maximum -= Utils.min(dice);
		if(maximum > 27) {
			return true;
		}
		return false;
	}
	
	public static boolean isKenta(int[] dice) {
		int[] brojanja = Utils.ponavljanje(dice);

		return (brojanja[0]>=1 && brojanja[1]>=1 && brojanja[2]>=1 && brojanja[3]>=1 && brojanja[4]>=1) ||
			       (brojanja[1]>=1 && brojanja[2]>=1 && brojanja[3]>=1 && brojanja[4]>=1 && brojanja[5]>=1);
	}
	
	public static boolean isTriling(int[] dice, ColumnType column) {
		int[] brojanja = Utils.ponavljanje(dice);
		int maxCount = Utils.max(brojanja);
		if (column == ColumnType.RUCNA) {
	        return maxCount == TRILING;
	    } else {
	        return maxCount >= TRILING;
	    }
	}
	
	public static boolean isFull(int[] dice) {
		int[] brojanja = Utils.ponavljanje(dice);
		return Utils.fullCheck(brojanja);
	}
	
	public static boolean isPoker(int[] dice) {
		int[] brojanja = Utils.ponavljanje(dice);
		return Utils.max(brojanja) >= POKER;
    }
	
	public static boolean isYamb(int[] dice) {
		int[] brojanja = Utils.ponavljanje(dice);
		return Utils.max(brojanja) >= YAMB;
	}
	
	public static boolean hasAtLeastOne(int[] dice, int number) {
	    for (int die : dice) {
	        if (die == number) {
	            return true;
	        }
	    }
	    return false;
	}

}
