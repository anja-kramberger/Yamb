package com.comtrade.yamb.player;

public class Konstante{
	public static final int KECEVI_POLJE = 0;
	public static final int DVOJKE_POLJE = 1;
	public static final int TROJKE_POLJE = 2;
	public static final int CETVORKE_POLJE = 3;
	public static final int PETICE_POLJE = 4;
	public static final int SESTICE_POLJE = 5;
	public static final int MAXIMUM_POLJE = 7;
	public static final int MINIMUM_POLJE = 8;
	public static final int KENTA_POLJE = 10;
	public static final int TRILING_POLJE = 11;
	public static final int FUL_POLJE = 12;
	public static final int POKER_POLJE = 13;
	public static final int YAMB_POLJE = 14;
	
	public static final int NADOLE_KOLONA = 0;
	public static final int SLOBODNA_KOLONA = 1;
	public static final int NAGORE_KOLONA = 2;
	public static final int ODSREDINE_KOLONA = 3;
	public static final int ODKRAJEVA_KOLONA = 4;
	public static final int NAJAVA_KOLONA = 5;
	public static final int RUCNA_KOLONA = 6;
}
