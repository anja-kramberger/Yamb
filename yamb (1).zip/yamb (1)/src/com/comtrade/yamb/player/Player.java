package com.comtrade.yamb.player;

import com.comtrade.yamb.Constants;
import com.comtrade.yamb.Die;
import com.comtrade.yamb.Field;
import com.comtrade.yamb.Board;
import com.comtrade.yamb.Column;
import com.comtrade.yamb.ColumnType;
import com.comtrade.yamb.FieldData;
import com.comtrade.yamb.FieldType;
import com.comtrade.yamb.Request;
import com.comtrade.yamb.RequestType;
import com.comtrade.yamb.Response;
import java.util.*;

public class Player {
	private Field targetField = null;
    private FieldData announcedField = null; 
    private ColumnType currentColumn;
    
	public Response play(Request request) {
		if (request.getType() != RequestType.THROW) return null;

	    Board board = request.getBoard();

	    List<Field> allFields = new ArrayList<>();
	    for (Column column : board.getColumns()) {
	        for (Field field : column.getFields()) {
	            allFields.add(field);
	        }
	    }

	    List<Field> availableFields   = PlayableFields.getAvailable(allFields);
	    Die[] dice = request.getDice();
	    int[] dices = simplifyDice(dice);
	    int throwNumber = request.getThrowNumber();

	    boolean moveOver = false;
	    boolean[] diceToKeep = new boolean[Constants.DICE_COUNT];
	    //FieldData fieldData = null;
	    FieldData fieldDataToReturn = null;
	    if (throwNumber == 1) {
	    	targetField = null;
            announcedField = null;
            
            //provera da li postoji ceo pattern
            Field exact = PatternChecker.findBestPattern(availableFields, dices, this.currentColumn);
            if (exact != null) {
                targetField = exact;
                diceToKeep = decideDiceToKeep(targetField, dices, throwNumber);

                ColumnType ct = targetField.getColumnType();
                if (ct == ColumnType.NAJAVA || ct == ColumnType.RUCNA) {
                    announcedField = new FieldData(targetField.getColumnIndex(), targetField.getFieldIndex());
                    fieldDataToReturn = announcedField;
                }
                moveOver = false;
                return new PlayerResponse(moveOver, diceToKeep, fieldDataToReturn);
            }

            //provera da li postoji kockica sa bar 2 ponavljanja
            int val = findValueWithAtLeastTwo(availableFields, dices);
            if (val != -1) {
                targetField = findNumberField(availableFields, val);
                diceToKeep = createKeepMask(dices, val);

                if (targetField != null) {
                    ColumnType ct = targetField.getColumnType();
                    if (ct == ColumnType.NAJAVA || ct == ColumnType.RUCNA) {
                        // only announce on throw 1 (we are on throw 1), and the RUCNA rule is enforced by findValueWithAtLeastTwo
                        announcedField = new FieldData(targetField.getColumnIndex(), targetField.getFieldIndex());
                        fieldDataToReturn = announcedField;
                    }
                }
                moveOver = false;
                return new PlayerResponse(moveOver, diceToKeep, fieldDataToReturn);
            }

            //biranje patterna sa najvecom sansom dobitka
            Field probable = PatternProbability.findMostLikelyPattern(availableFields, dices, throwNumber);
            if (probable != null) {
                targetField = probable;
                diceToKeep = decideDiceToKeep(targetField, dices, throwNumber);

                ColumnType ct = targetField.getColumnType();
                if (ct == ColumnType.NAJAVA || ct == ColumnType.RUCNA) {
                    announcedField = new FieldData(targetField.getColumnIndex(), targetField.getFieldIndex());
                    fieldDataToReturn = announcedField;
                }
                moveOver = false;
                return new PlayerResponse(moveOver, diceToKeep, fieldDataToReturn);
            }

            Arrays.fill(diceToKeep, false);
            moveOver = false;
            return new PlayerResponse(moveOver, diceToKeep, null);
	    }

	    else if (throwNumber == 2) {

	    	if (targetField != null) {
                diceToKeep = decideDiceToKeep(targetField, dices, throwNumber);
                return new PlayerResponse(false, diceToKeep, null);
            }

            Field exactNow = PatternChecker.findBestPattern(availableFields, dices, this.currentColumn);
            if (exactNow != null) {
                targetField = exactNow;
                diceToKeep = decideDiceToKeep(targetField, dices, throwNumber);
                return new PlayerResponse(false, diceToKeep, null);
            }

            Field probableNow = PatternProbability.findMostLikelyPattern(availableFields, dices, throwNumber);
            if (probableNow != null) {
                targetField = probableNow;
                diceToKeep = decideDiceToKeep(targetField, dices, throwNumber);
                return new PlayerResponse(false, diceToKeep, null);
            }

            Arrays.fill(diceToKeep, false);
            return new PlayerResponse(false, diceToKeep, null);
	        
	    } 
	    else if (throwNumber == 3) {

	    	if (targetField != null) {
                fieldDataToReturn = new FieldData(targetField.getColumnIndex(), targetField.getFieldIndex());
            } else {
                Field finalPick = chooseFinalField(availableFields, dices);
                if (finalPick != null) {
                    fieldDataToReturn = new FieldData(finalPick.getColumnIndex(), finalPick.getFieldIndex());
                } else {
                    fieldDataToReturn = null;
                }
            }
            moveOver = true;

            targetField = null;
            announcedField = null;

            return new PlayerResponse(moveOver, new boolean[Constants.DICE_COUNT], fieldDataToReturn);
        }
	    	
	    return new PlayerResponse(false, new boolean[Constants.DICE_COUNT], null);
	}
	

	private int findValueWithAtLeastTwo(List<Field> availableFields, int[] dices) {
        int[] counts = Utils.ponavljanje(dices); 
        int bestVal = -1;
        int bestCount = 0;

        for (int val = 6; val >= 1; val--) {
            int c = counts[val - 1];
            if (c < 2) continue;

            Field nf = findNumberField(availableFields, val);
            if (nf == null) continue;

            int required = (nf.getColumnType() == ColumnType.RUCNA) ? 3 : 2;
            if (c >= required) {
                if (c > bestCount || (c == bestCount && val > bestVal)) {
                    bestVal = val;
                    bestCount = c;
                }
            }
        }
        return bestVal == -1 ? -1 : bestVal;
    }

	private Field findNumberField(List<Field> availableFields, int value) {
        String name = "FIELD_" + value;
        for (Field f : availableFields) {
            if (f.getFieldType().name().equals(name)) return f;
        }
        return null;
    }

	private boolean[] decideDiceToKeep(Field target, int[] dice, int throwNumber) {
        boolean[] keep = new boolean[dice.length];
        if (target == null) {
            Arrays.fill(keep, false);
            return keep;
        }
        
        FieldType type = target.getFieldType();
        int[] counts = Utils.ponavljanje(dice); 
        int rollsLeft = 3 - throwNumber;
        switch (type) {
            case YAMB:
            case POKER:
            case TRILING: {
                /*int most = 0;
                for (int i = 0; i < counts.length; i++) {
                    if (counts[i] > counts[most]) most = i;
                }
                int bestValue = most + 1;

                if (this.currentColumn == ColumnType.RUCNA) {
                    for (int i = 0; i < dice.length; i++) {
                        keep[i] = (counts[dice[i] - 1] >= 2);
                    }
                } else {
                    for (int i = 0; i < dice.length; i++) {
                        keep[i] = (dice[i] == bestValue);
                    }
                }
                break;*/
            	
                int most = 0;
                for (int i = 0; i < counts.length; i++) {
                    if (counts[i] > counts[most]) most = i;
                }
                int bestValue = most + 1;

                if (counts[most] >= 4 && throwNumber < 3) {
                    for (int i = 0; i < dice.length; i++) {
                        keep[i] = (dice[i] == bestValue);
                    }
                } else {
                    for (int i = 0; i < dice.length; i++) {
                        keep[i] = (dice[i] == bestValue);
                    }
                }
                break;
            }

            case FULL: {
            	/*int[] counts = Utils.ponavljanje(dice);
                int triple = -1, pair = -1;

                for (int i = 0; i < counts.length; i++) {
                    if (counts[i] >= 3) triple = i + 1;
                }
                for (int i = 0; i < counts.length; i++) {
                    if (counts[i] >= 2 && (i + 1) != triple) pair = i + 1;
                }

                if (this.currentColumn == ColumnType.RUCNA) {
                    for (int i = 0; i < dice.length; i++) {
                        keep[i] = (counts[dice[i] - 1] >= 2);
                    }
                } else {
                    for (int i = 0; i < dice.length; i++) {
                        keep[i] = (dice[i] == triple || dice[i] == pair);
                    }
                }
                break;*/
            	int triple = -1, pair = -1;
                for (int i = 0; i < counts.length; i++) {
                    if (counts[i] >= 3) triple = i + 1;
                }
                for (int i = 0; i < counts.length; i++) {
                    if (counts[i] >= 2 && (i + 1) != triple) pair = i + 1;
                }

                if (triple != -1 && counts[triple - 1] == 4 && rollsLeft >= 2) {
                    for (int i = 0; i < dice.length; i++) {
                        keep[i] = (dice[i] == triple);
                    }
                } else {
                    for (int i = 0; i < dice.length; i++) {
                        keep[i] = (dice[i] == triple || dice[i] == pair);
                    }
                }
                break;
            }

            case KENTA: {
                /*for (int i = 0; i < dice.length; i++) {
                    keep[i] = (dice[i] >= 2 && dice[i] <= 5);
                }
                break;*/
            	boolean[] has = new boolean[7];
                for (int d : dice) has[d] = true;
                boolean aimingLow = has[1] || (!has[6] && has[2]);
                int[] targetKenta = aimingLow ? new int[]{1, 2, 3, 4, 5}
                                              : new int[]{2, 3, 4, 5, 6};
                for (int i = 0; i < dice.length; i++) {
                    for (int t : targetKenta) {
                        if (dice[i] == t) {
                            keep[i] = true;
                            break;
                        }
                    }
                }
                break;
            	
            }

            case MAXIMUM: {
                for (int i = 0; i < dice.length; i++) keep[i] = (dice[i] >= 5);
                break;
            }

            case MINIMUM: {
                for (int i = 0; i < dice.length; i++) keep[i] = (dice[i] <= 2);
                break;
            }

            case FIELD_1: case FIELD_2: case FIELD_3:
            case FIELD_4: case FIELD_5: case FIELD_6: {
                int targetNum = Integer.parseInt(type.name().split("_")[1]);
                for (int i = 0; i < dice.length; i++) keep[i] = (dice[i] == targetNum);
                break;
            }

            default:
                Arrays.fill(keep, false);
                break;
        }
        return keep;
    }

	private Field chooseFinalField(List<Field> availableFields, int[] dices) {
        if (availableFields == null || availableFields.isEmpty()) return null;
        availableFields.sort(Comparator.comparingInt(PriorityHandler::getPriority).reversed());
        return availableFields.get(0);
    }
	
	private boolean[] createKeepMask(int[] dices, int value) {
	    boolean[] keep = new boolean[Constants.DICE_COUNT];
	    for (int i = 0; i < dices.length; i++) {
	        if (dices[i] == value) keep[i] = true;
	    }
	    return keep;
	}

	private int[] simplifyDice(Die[] dice) {
		int[] kockice = new int[Constants.DICE_COUNT];
		for (int i = 0; i < Constants.DICE_COUNT; i++) {
			kockice[i] = dice[i].getValue();
		}
		return kockice;
	}

}
