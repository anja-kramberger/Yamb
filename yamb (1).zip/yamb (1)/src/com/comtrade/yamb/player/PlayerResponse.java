package com.comtrade.yamb.player;

import com.comtrade.yamb.FieldData;
import com.comtrade.yamb.Response;

public class PlayerResponse implements Response {
	
	private boolean moveOver;
	private boolean[] dice;
	private FieldData fieldData;
	
	public PlayerResponse(boolean moveOver, boolean[] dice, FieldData fieldData) {
		this.moveOver = moveOver;
		this.dice = dice;
		this.fieldData = fieldData;
	}

	@Override
	public boolean isMoveOver() {
		return moveOver;
	}
	// TRUE ako se cuvaju, FALSE suprotno
	@Override
	public boolean[] getDice() {
		return dice;
	}

	@Override
	public FieldData getFieldData() {
		return fieldData;
	}

}
