package com.comtrade.yamb.implementation;

class YambException extends Exception {
   private static final long serialVersionUID = 1L;

   YambException(String message) {
      super(message);
   }
}
