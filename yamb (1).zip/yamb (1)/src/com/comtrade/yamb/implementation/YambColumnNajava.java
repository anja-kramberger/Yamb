package com.comtrade.yamb.implementation;

import com.comtrade.yamb.ColumnType;

class YambColumnNajava extends YambColumn {
   protected YambColumnNajava() {
      super(ColumnType.NAJAVA);
   }
}
