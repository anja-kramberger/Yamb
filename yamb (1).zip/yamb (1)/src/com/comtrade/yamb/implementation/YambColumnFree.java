package com.comtrade.yamb.implementation;

import com.comtrade.yamb.ColumnType;

class YambColumnFree extends YambColumn {
   protected YambColumnFree() {
      super(ColumnType.FREE);
   }
}
