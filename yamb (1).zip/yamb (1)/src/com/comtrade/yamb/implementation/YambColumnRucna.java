package com.comtrade.yamb.implementation;

import com.comtrade.yamb.ColumnType;

class YambColumnRucna extends YambColumn {
   protected YambColumnRucna() {
      super(ColumnType.RUCNA);
   }
}
